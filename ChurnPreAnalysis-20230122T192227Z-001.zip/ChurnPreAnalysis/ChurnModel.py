import pandas as modelPd
import matplotlib.pyplot as edaPlt
import pickle


edaDf = modelPd.read_csv("tel_churn2.csv")

print(edaDf.head())

print(edaDf.dropna(inplace=True))
print("555599999",edaDf.shape)

modelX=edaDf.drop('Churn',axis=1)
print(modelX)

print("/////////fina",modelX.fillna(0))
modelY=edaDf['Churn']
print(modelY)

#////////////code from other site

import seaborn as sns
sns.countplot(edaDf['Churn'])
edaPlt.show()

Xb = edaDf.drop('Churn',axis=1)
Yb = edaDf['Churn']

from imblearn.over_sampling import SMOTE
X_res,y_res = SMOTE().fit_resample(Xb,Yb)
print("$$$$$$$$$$$$smote",y_res.value_counts())

from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test=train_test_split(X_res,y_res,test_size=0.20,random_state=42)

from sklearn.preprocessing import StandardScaler
sc= StandardScaler()
X_train=sc.fit_transform(X_train)
X_test = sc.transform(X_test)
print(X_train)

from sklearn.linear_model import LogisticRegression
log = LogisticRegression()
log.fit(X_train,y_train)

LogisticRegression()
y_pred1 = log.predict(X_test)
from sklearn.metrics import accuracy_score

print(accuracy_score(y_test,y_pred1))

print(accuracy_score(y_test,y_pred1))
from sklearn.metrics import precision_score,recall_score,f1_score

print(precision_score(y_test,y_pred1))

print(recall_score(y_test,y_pred1))

print(f1_score(y_test,y_pred1))

from sklearn import svm
svm = svm.SVC()
svm.fit(X_train,y_train)

y_pred2 = svm.predict(X_test)

print("svm score",accuracy_score(y_test,y_pred2))

print("svm score",precision_score(y_test,y_pred2))

from sklearn.neighbors import KNeighborsClassifier
knn = KNeighborsClassifier()
knn.fit(X_train,y_train)
KNeighborsClassifier()
y_pred3 = knn.predict(X_test)

print("neighbour score",accuracy_score(y_test,y_pred3))

print("neighbour score",precision_score(y_test,y_pred3))

from sklearn.tree import DecisionTreeClassifier
dt = DecisionTreeClassifier()
dt.fit(X_train,y_train)
DecisionTreeClassifier()
y_pred4 = dt.predict(X_test)
print("dtc score",accuracy_score(y_test,y_pred4))

print("dtc score",precision_score(y_test,y_pred4))

from sklearn.ensemble import RandomForestClassifier
rf = RandomForestClassifier()
rf.fit(X_train,y_train)
RandomForestClassifier()
y_pred5 = rf.predict(X_test)
print("rfc score",accuracy_score(y_test,y_pred5))

print("rfc score",precision_score(y_test,y_pred5))

from sklearn.ensemble import GradientBoostingClassifier
gbc = GradientBoostingClassifier()
gbc.fit(X_train,y_train)
GradientBoostingClassifier()
y_pred6 = gbc.predict(X_test)

print("gbc score",accuracy_score(y_test,y_pred6))

print("gbc score",precision_score(y_test,y_pred6))


final_data=modelPd.DataFrame({'Models':['LR','SVC','KNN','DT','RF','GBC'],
                        'ACC':[accuracy_score(y_test,y_pred1),
                              accuracy_score(y_test,y_pred2),
                              accuracy_score(y_test,y_pred3),
                              accuracy_score(y_test,y_pred4),
                              accuracy_score(y_test,y_pred5),
                              accuracy_score(y_test,y_pred6)]})

print(final_data)

import seaborn as sns
sns.barplot(final_data['Models'],final_data['ACC'])
edaPlt.show()

X_res=sc.fit_transform(X_res)
rf.fit(X_res,y_res)






model_rf_smote=RandomForestClassifier(n_estimators=100, criterion='gini', random_state = 100,max_depth=6, min_samples_leaf=8)

model_rf_smote.fit(Xb,Yb)



modelFileName = 'churnModel.sav'
pickle.dump(model_rf_smote, open(modelFileName, 'wb'))
load_model = pickle.load(open(modelFileName, 'rb'))
model_score_r1 = load_model.score(X_res, y_res)
print(model_score_r1)

