# coding: utf-8

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn import metrics
from flask import Flask, request, render_template
import pickle

churnApp = Flask("__name__")

appDataFrame=pd.read_csv("C:/Users/City College/Downloads/first.csv")

#df_1=df_1.drop("id", axis=1)

print(appDataFrame.head())

q = ""

@churnApp.route("/")
def loadPage():
	return render_template('ChurnHome.html', query="")

@churnApp.route("/", methods=['POST'])
def predict():
	appQuery1 = request.form.get('query1', False)
	appQuery2 = request.form.get('query2', False)
	appQuery3 = request.form.get('query3', False)
	appQuery4 = request.form.get('query4', False)
	appQuery5 = request.form.get('query5', False)
	appQuery6 = request.form.get('query6', False)
	appQuery7 = request.form.get('query7', False)
	appQuery8 = request.form.get('query8', False)
	appQuery9 = request.form.get('query9', False)
	appQuery10 = request.form.get('query10', False)
	appQuery11 = request.form.get('query11', False)
	appQuery12 = request.form.get('query12', False)
	appQuery13 = request.form.get('query13', False)
	appQuery14 = request.form.get('query14', False)
	appQuery15 = request.form.get('query15', False)
	appQuery16 = request.form.get('query16', False)
	appQuery17 = request.form.get('query17', False)
	appQuery18 = request.form.get('query18', False)
	appQuery19 = request.form.get('query19', False)

	appModel = pickle.load(open("churnModel.sav", "rb"))

	data = [[appQuery1, appQuery2, appQuery3, appQuery4, appQuery5, appQuery6, appQuery7,
			 appQuery8, appQuery9, appQuery10, appQuery11, appQuery12, appQuery13, appQuery14,
			 appQuery15, appQuery16, appQuery17, appQuery18, appQuery19]]

	for x in range(len(data)):
		print(data[x],"/n")


	appNewDataFrame = pd.DataFrame(data, columns=['SeniorCitizen', 'MonthlyCharges', 'TotalCharges', 'gender',
										 'Partner', 'Dependents', 'PhoneService', 'MultipleLines', 'InternetService',
										 'OnlineSecurity', 'OnlineBackup', 'DeviceProtection', 'TechSupport',
										 'StreamingTV', 'StreamingMovies', 'Contract', 'PaperlessBilling',
										 'PaymentMethod', 'tenure'])


	for col in appNewDataFrame.columns:
		print("col in new df /n",col)


	appDataFrame2 = pd.concat([appDataFrame, appNewDataFrame], ignore_index=True)
	# Group the tenure in bins of 12 months
	appLabels = ["{0} - {1}".format(i, i + 11) for i in range(1, 72, 12)]

	appDataFrame2['tenure_group'] = pd.cut(appDataFrame2.tenure.astype(int), range(1, 80, 12), right=False, labels=appLabels)
	# drop column customerID and tenure
	appDataFrame2.drop(columns=['tenure'], axis=1, inplace=True)

	for col in appDataFrame2.columns:
		print("col in df_2 /n",col)

	appDataFrameDummies = pd.get_dummies(appDataFrame2[['gender', 'SeniorCitizen', 'Partner', 'Dependents', 'PhoneService',
										   'MultipleLines', 'InternetService', 'OnlineSecurity', 'OnlineBackup',
										   'DeviceProtection', 'TechSupport', 'StreamingTV', 'StreamingMovies', 'Contract',]])

	# appDataFrameDummies.drop('gender_0',axis=1,inplace=True)
	# appDataFrameDummies.drop('Dependents_No', axis=1, inplace=True)

	#'StreamingMovies','Contract', 'PaperlessBilling', 'PaymentMethod', 'tenure_group'

	# new_df__dummies.drop(['gender_Female'],axis=1, inplace=True)
	# new_df__dummies.drop(['gender_Male'],axis=1, inplace=True)
	# new_df__dummies.drop(['gender_Male'],axis=1, inplace=True)
	# new_df__dummies.drop(['SeniorCitizen_0'],axis=1, inplace=True)
	# new_df__dummies.drop(['SeniorCitizen_1'],axis=1, inplace=True)
	# new_df__dummies.drop(['SeniorCitizen_yes'],axis=1, inplace=True)
	# new_df__dummies.drop(['Partner_No'],axis=1, inplace=True)
	# new_df__dummies.drop(['Partner_Yes'],axis=1, inplace=True)
	# new_df__dummies.drop(['Dependents_No'],axis=1, inplace=True)
	# new_df__dummies.drop(['Dependents_Yes'],axis=1, inplace=True)
	# new_df__dummies.drop(['Dependents_no'],axis=1, inplace=True)
	# new_df__dummies.drop(['PhoneService_No'],axis=1, inplace=True)
	# new_df__dummies.drop(['PhoneService_Yes'],axis=1, inplace=True)
	# new_df__dummies.drop(['PhoneService_yes'],axis=1, inplace=True)
	# new_df__dummies.drop(['MultipleLines_No'],axis=1, inplace=True)

	# for col in new_df__dummies.columns:
	# 	print("col in dummies /n",col)

	# print("df-dumm",new_df__dummies.shape)
	print("new df",appNewDataFrame.shape)
	print("df2 ",appDataFrame2.shape)

	# final_df=pd.concat([new_df__dummies, new_dummy], axis=1)

	appSingle = appModel.predict(appDataFrameDummies.tail(1))
	appProbablity = appModel.predict_proba(appDataFrameDummies.tail(1))[:, 1]

	if appSingle == 1:
		o1 = "This customer is likely to be churned!!"
		o2 = "Confidence: {}".format(appProbablity * 100)
	else:
		o1 = "This customer is likely to continue!!"
		o2 = "Confidence: {}".format(appProbablity * 100)

	return render_template('/ChurnHome.html', output1=o1, output2=o2,

						   query1=request.form.get('query1', False),
						   query2=request.form.get('query2', False),
						   query3=request.form.get('query3', False),
						   query4=request.form.get('query4', False),
						   query5=request.form.get('query5', False),
						   query6=request.form.get('query6', False),
						   query7=request.form.get('query7', False),
						   query8=request.form.get('query8', False),
						   query9=request.form.get('query9', False),
						   query10=request.form.get('query10', False),
						   query11=request.form.get('query11', False),
						   query12=request.form.get('query12', False),
						   query13=request.form.get('query13', False),
						   query14=request.form.get('query14', False),
						   query15=request.form.get('query15', False),
						   query16=request.form.get('query16', False),
						   query17=request.form.get('query17', False),
						   query18=request.form.get('query18', False),
						   query19=request.form.get('query19', False))

churnApp.run(debug=True)


