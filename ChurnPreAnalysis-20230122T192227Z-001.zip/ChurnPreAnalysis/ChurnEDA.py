#import the required libraries

import matplotlib
import numpy as edaNp
import pandas as edaPd
import seaborn as edaSns
import matplotlib.ticker as edaTick
import matplotlib.pyplot as edaPlt

edaData = edaPd.read_csv("C:/Users/City College/Downloads/churnEDA.csv.txt")

print(edaData.head())

print(edaData.shape)

print(edaData.columns.values)

# Checking the data types of all the columns
print(edaData.dtypes)

# Check the descriptive statistics of numeric variables
print(edaData.describe())

edaData['Churn'].value_counts().plot(kind='barh', figsize=(8, 6))
edaPlt.xlabel("Count", labelpad=14)
edaPlt.ylabel("Main Var", labelpad=14)
edaPlt.title("Number of main Var per feature", y=1.02)
edaPlt.show()

print(100*edaData['Churn'].value_counts()/len(edaData['Churn']))

print(edaData['Churn'].value_counts())

# To have brief summary of edaDataFrame
print(edaData.info(verbose = True))

missing = edaPd.DataFrame((edaData.isnull().sum())*100/edaData.shape[0]).reset_index()
edaPlt.figure(figsize=(5,5))
ax = edaSns.pointplot('index',0,data=missing)
edaPlt.xticks(rotation =90,fontsize =7)
edaPlt.title("% of unavailable data")
edaPlt.ylabel("PERCENTAGE")
edaPlt.show()

edaCopiedData = edaData.copy()

edaCopiedData.TotalCharges = edaPd.to_numeric(edaCopiedData.TotalCharges, errors='coerce')
print(edaCopiedData.isnull().sum())

print(edaCopiedData.loc[edaCopiedData ['TotalCharges'].isnull() == True])

# Getting maximum value of tenure
print(edaCopiedData['tenure'].max())

# Grouping the feature "tenure" on the basis of twelve months
labels = ["{0} - {1}".format(i, i + 11) for i in range(1, 72, 12)]

edaCopiedData['tenure_group'] = edaPd.cut(edaCopiedData.tenure, range(1, 80, 12), right=False, labels=labels)
print(edaCopiedData['tenure_group'].value_counts())

# deleting features(custId and tenure)
edaCopiedData.drop(columns= ['customerID','tenure'], axis=1, inplace=True)
print(edaCopiedData.head())

#commented because of contiues plots
# for j, predictor in enumerate(edaCopiedData.drop(columns=['Churn', 'TotalCharges', 'MonthlyCharges'])):
#     edaPlt.figure(j)
#     edaSns.countplot(data=edaCopiedData, x=predictor, hue='Churn')
#     edaPlt.show()

edaCopiedData['Churn'] = edaNp.where(edaCopiedData.Churn == 'Yes',1,0)
print(edaCopiedData.head())

edaCopiedDataDummies = edaPd.get_dummies(edaCopiedData)
print(edaCopiedDataDummies.head())

edaSns.lmplot(data=edaCopiedDataDummies, x='MonthlyCharges', y='TotalCharges', fit_reg=False)

Mth = edaSns.kdeplot(edaCopiedDataDummies.MonthlyCharges[(edaCopiedDataDummies["Churn"] == 0) ],
                color="Red", shade = True)
Mth = edaSns.kdeplot(edaCopiedDataDummies.MonthlyCharges[(edaCopiedDataDummies["Churn"] == 1) ],
                ax =Mth, color="Blue", shade= True)
Mth.legend(["No Churn","Churn"],loc='upper right')
Mth.set_ylabel('Density')
Mth.set_xlabel('Monthly Charges')
Mth.set_title('Monthly charges by churn')

Tot = edaSns.kdeplot(edaCopiedDataDummies.TotalCharges[(edaCopiedDataDummies["Churn"] == 0) ],
                color="Pink", shade = True)
Tot = edaSns.kdeplot(edaCopiedDataDummies.TotalCharges[(edaCopiedDataDummies["Churn"] == 1) ],
                ax =Tot, color="Green", shade= True)
Tot.legend(["No Churn","Churn"],loc='upper right')
Tot.set_ylabel('Density')
Tot.set_xlabel('Total Charges')
Tot.set_title('Total charges by churn')

edaPlt.figure(figsize=(8,8))
edaCopiedDataDummies.corr()['Churn'].sort_values(ascending = False).plot(kind='bar')
edaPlt.show()

edaPlt.figure(figsize=(12,12))
edaSns.heatmap(edaCopiedDataDummies.corr(), cmap="Paired")
edaPlt.show()

edaTarget0=edaCopiedData.loc[edaCopiedData["Churn"]==0]
edaTarget1=edaCopiedData.loc[edaCopiedData["Churn"]==1]


def uniplot(df, col, title, hue=None):
    edaSns.set_style('whitegrid')
    edaSns.set_context('talk')
    edaPlt.rcParams["axes.labelsize"] = 20
    edaPlt.rcParams['axes.titlesize'] = 22
    edaPlt.rcParams['axes.titlepad'] = 30

    edaTemp = edaPd.Series(data=hue)
    edaFig, edaAx = edaPlt.subplots()
    width = len(df[col].unique()) + 7 + 4 * len(edaTemp.unique())
    edaFig.set_size_inches(width, 8)
    edaPlt.xticks(rotation=45)
    edaPlt.yscale('log')
    edaPlt.title(title)
    edaAx = edaSns.countplot(data=df, x=col, order=df[col].value_counts().index, hue=hue, palette='bright')

    edaPlt.show()

    uniplot(edaTarget1, col='Partner', title='Distribution of Gender for Churned Customers', hue='gender')

    uniplot(edaTarget0, col='Partner', title='Distribution of Gender for Non Churned Customers', hue='gender')

    uniplot(edaTarget1, col='PaymentMethod', title='Distribution of PaymentMethod for Churned Customers',
            hue='gender')

    uniplot(edaTarget1, col='Contract', title='Distribution of Contract for Churned Customers', hue='gender')

    uniplot(edaTarget0, col='TechSupport', title='Distribution of TechSupport for Churned Customers', hue='gender')

    uniplot(edaTarget1, col='SeniorCitizen', title='Distribution of SeniorCitizen for Churned Customers',
            hue='gender')

edaCopiedDataDummies.to_csv('tel_churn2.csv')

